package practice;

public class Welcome {
public static void main(String [] args){
	
	System.out.println("Welcome to Java Programming");
	
	
}
}
