package practice;

public class CommandTest {
	public static void main(String []args){
		String argOne = args[0];
		String argTwo = args[1];
		
		System.out.println(argOne);
		System.out.println(argTwo);
		
	}

}
