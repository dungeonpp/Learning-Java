package practice;

public class VariablesType{
	int x=10;
	static int y=20;
	public static void main(String[] args) 
	{
	VariablesType t1=new VariablesType();
	t1.x=888;
	t1.y=999;
	VariablesType t2=new VariablesType();
	System.out.println(t2.x+"----"+t2.y);
	new VariablesType();
	VariablesType v1;
	
	
	}
	}