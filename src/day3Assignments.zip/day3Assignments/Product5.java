package com.day3;

public class Product5 {
	String productCode;
	String productName;
	String productPrice;
	String categoryCode;
	public static int prodCounter=100;
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public static int getProdCounter() {
		return prodCounter;
	}
	public static void setProdCounter(int prodCounter) {
		Product.prodCounter = prodCounter;
	}
	private String genrateProductCode()
	{
		return categoryCode+prodCounter++;
		
	}
	public Product(String productName, String productPrice, String categoryCode) {
		super();
		this.productName = productName;
		this.productPrice = productPrice;
		this.categoryCode = categoryCode;
		this.productCode=genrateProductCode();
	}
	public Product(String productName, String productPrice) {
		super();
		this.productName = productName;
		this.productPrice = productPrice;
		this.categoryCode = "E";
		this.productCode=genrateProductCode();
	}
	public String getProductDetails()
	{
		return "Product Code:"+productCode+" Product Name :"+productName+" Product Price: "+productPrice+" Category : "+categoryCode;
		
	}
}
