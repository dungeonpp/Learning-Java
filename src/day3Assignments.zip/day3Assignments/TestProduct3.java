package day3Assignments;

public class TestProduct3 {
public static void main(String[] args) {
	Product3 prod1= new Product3("A1234","Oil",123.234);
	prod1.displayProductDetails(prod1);	
}
}
