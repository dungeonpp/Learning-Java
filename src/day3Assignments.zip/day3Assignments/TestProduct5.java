package com.day3;

public class TestProduct5 {

	public static void main(String[] args) {
		Product p=new Product("Laptop","25000","L");
		System.out.println(p.getProductDetails());
		Product p1=new Product("Mobile","12000");
		System.out.println(p1.getProductDetails());
	}

}
