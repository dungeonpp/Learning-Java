package day3Assignments;

public class Averager {
	
	static double avg(int number1 ,int number2)
	{
		double average = (number1+number2)/2;
		return average;
	}
	
	static double avg(int number1 ,int number2,int number3)
	{
		double average = (number1+number2+number3)/3;
		return average;
	}
	
	static double avg(double number1 ,double number2)
	{
		double average = (number1+number2)/2;
		return average;
	}
}
