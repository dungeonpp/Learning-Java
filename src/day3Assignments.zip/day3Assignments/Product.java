package day3Assignments;

public class Product {
	String productCode;
	String productName;
	double productPrice;

}
